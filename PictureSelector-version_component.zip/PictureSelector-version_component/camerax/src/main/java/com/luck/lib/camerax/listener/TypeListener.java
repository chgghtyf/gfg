package com.luck.lib.camerax.listener;

/**
 * @author：luck
 * @date：2020-01-04 13:38
 * @describe：TypeListener
 */
public interface TypeListener {
    void cancel();

    void confirm();
}
