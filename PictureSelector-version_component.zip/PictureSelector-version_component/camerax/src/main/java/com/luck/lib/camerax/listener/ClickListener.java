package com.luck.lib.camerax.listener;

/**
 * @author：luck
 * @date：2020-01-04 13:45
 * @describe：点击事件监听
 */
public interface ClickListener {
    void onClick();
}
