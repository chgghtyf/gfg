package com.luck.picture.lib.interfaces;

/**
 * @author：luck
 * @date：2020-04-14 18:44
 * @describe：OnRecyclerViewPreloadMoreListener
 */
public interface OnRecyclerViewPreloadMoreListener {
    /**
     * load more
     */
    void onRecyclerViewPreloadMore();
}
