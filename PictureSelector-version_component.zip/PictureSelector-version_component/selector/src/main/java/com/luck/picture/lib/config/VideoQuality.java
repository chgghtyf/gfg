package com.luck.picture.lib.config;

/**
 * @author：luck
 * @date：2022/1/9 10:27 上午
 * @describe：VideoQuality
 */
public class VideoQuality {
    public static final int VIDEO_QUALITY_LOW = 0;
    public static final int VIDEO_QUALITY_HIGH = 1;
}
