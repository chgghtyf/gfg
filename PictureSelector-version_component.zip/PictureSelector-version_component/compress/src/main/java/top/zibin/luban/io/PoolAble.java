package top.zibin.luban.io;

/**
 * @author：luck
 * @date：2021/8/26 3:12 下午
 * @describe：PoolAble
 */
public interface PoolAble {
    void offer();
}
